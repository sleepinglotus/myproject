package cn.bdqn.dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import cn.bdqn.entity.EasyBuyNews;

public class EasyBuyNewsDao extends BaseDao {

	public List<EasyBuyNews> findTen() {
		List<EasyBuyNews> easyBuyNewsList=new ArrayList<>();
		String sql="SELECT `enId`,`title`,`content`,`createTime` FROM `EasybuyNews` ORDER BY `createTime` DESC LIMIT 0,10";
		try {
			rs=super.executeQuery(sql);
			while(rs.next()) {
				int enId=rs.getInt("enId");
				String title=rs.getString("title");
				String content=rs.getString("content");
				Timestamp createTime=rs.getTimestamp("createTime");
				easyBuyNewsList.add(new EasyBuyNews(enId,title,content,createTime));
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyNewsList;
	}

	public EasyBuyNews findByEnId(int id) {
		EasyBuyNews easyBuyNews=null;
		String sql="SELECT `enId`,`title`,`content`,`createTime` FROM `EasybuyNews` WHERE `enId`=?";
		try {
			rs=super.executeQuery(sql, id);
			if(rs.next()) {
				int enId=rs.getInt("enId");
				String title=rs.getString("title");
				String content=rs.getString("content");
				Timestamp createTime=rs.getTimestamp("createTime");
				easyBuyNews=new EasyBuyNews(enId,title,content,createTime);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyNews;
	}

	public int getTotalCount() {
		int count=0;
		String sql="SELECT COUNT(`enId`) FROM `EasybuyNews`";
		try {
			rs=super.executeQuery(sql);
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		
		return count;
	}

	public List<EasyBuyNews> findByPage(int pageNo, int pageSize) {
		List<EasyBuyNews> easyBuyNewsList=new ArrayList<>();
		String sql="SELECT `enId`,`title`,`content`,`createTime` FROM `EasybuyNews` ORDER BY `createTime` DESC LIMIT ?,?";
		try {
			rs=super.executeQuery(sql, (pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int enId=rs.getInt("enId");
				String title=rs.getString("title");
				String content=rs.getString("content");
				Timestamp createTime=rs.getTimestamp("createTime");
				easyBuyNewsList.add(new EasyBuyNews(enId, title, content, createTime));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyNewsList;
	}

	public int addNews(String title, String content, Timestamp createTime) {
		String sql="INSERT INTO `EasybuyNews`(`title`,`content`,`createTime`) VALUES(?,?,?);";
		return super.executeUpdate(sql, title, content, createTime);
	}

	public int updateNews(String title, String content, Timestamp createTime,int enId) {
		String sql="UPDATE `EasyBuyNews` SET `title`=?,`content`=?,`createTime`=? WHERE `enId`=?";
		return super.executeUpdate(sql, title, content, createTime, enId);
	}

	public int delNews(int enId) {
		String sql="DELETE FROM `EasyBuyNews` WHERE `enId`=?";
		return super.executeUpdate(sql, enId);
	}

}
