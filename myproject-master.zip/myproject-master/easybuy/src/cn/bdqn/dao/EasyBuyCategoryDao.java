package cn.bdqn.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.bdqn.entity.EasyBuyCategory;


public class EasyBuyCategoryDao extends BaseDao{

	public List<EasyBuyCategory> findAll() {
		List<EasyBuyCategory> easyBuyCategoryList=new ArrayList<EasyBuyCategory>();
		String sql="SELECT `epcId`,`epcName`,`parentId`,`type` FROM `EasyBuyCategory` ORDER BY `parentId`";
		try {
			rs=super.executeQuery(sql);
			while(rs.next()){
				int epcId=rs.getInt("epcId");
				String epcName=rs.getString("epcName");
				int parentId=rs.getInt("parentId");
				int type=rs.getInt("type");
				easyBuyCategoryList.add(new EasyBuyCategory(epcId, epcName, parentId, type));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyCategoryList;
	}

	public EasyBuyCategory findByEpcId(int id) {
		EasyBuyCategory easyBuyCategory=null;
		String sql="SELECT `epcId`,`epcName`,`parentId`,`type` FROM `easybuycategory` WHERE `epcId`=?";
		try {
			rs=super.executeQuery(sql,id);
			while(rs.next()){
				int epcId=rs.getInt("epcId");
				String epcName=rs.getString("epcName");
				int parentId=rs.getInt("parentId");
				int type=rs.getInt("type");
				easyBuyCategory=new EasyBuyCategory(epcId, epcName, parentId, type);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyCategory;
	}

	public int getTotalCount() {
		int count=0;
		String sql="SELECT COUNT(`epcId`) FROM `EasyBuyCategory`";
		try {
			rs=super.executeQuery(sql);
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		
		return count;
	}

	public List<EasyBuyCategory> findByPage(int pageNo, int pageSize) {
		List<EasyBuyCategory> easyBuyCategoryList=new ArrayList<>();
		String sql="SELECT `epcId`,`epcName`,`parentId`,`type` FROM `EasyBuyCategory` ORDER BY `parentId` LIMIT ?,?";
		try {
			rs=super.executeQuery(sql, (pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int epcId=rs.getInt("epcId");
				String epcName=rs.getString("epcName");
				int parentId=rs.getInt("parentId");
				int type=rs.getInt("type");
				easyBuyCategoryList.add(new EasyBuyCategory(epcId, epcName, parentId, type));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyCategoryList;
	}

	public int updateCategory(String epcName, int parentId, int type, int epcId) {
		String sql="UPDATE `EasyBuyCategory` SET `epcName`=?,`parentId`=?,`type`=? WHERE `epcId`=?";
		return super.executeUpdate(sql, epcName,parentId,type,epcId);
	}

	public int delCategory(int epcId) {
		String sql="DELETE FROM `EasyBuyCategory` WHERE `epcId`=?";
		return super.executeUpdate(sql, epcId);
	}

	public int getCountByType(int type) {
		int count=0;
		String sql="SELECT COUNT(`parentId`) FROM `EasyBuyCategory` WHERE `type`=?";
		try {
			rs=super.executeQuery(sql,type);
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		
		return count;
	}

	public int addCategory(String epcName, int parentId, int type) {
		String sql="INSERT INTO easybuycategory (`epcName`,`parentId`,`type`) VALUES(?, ?, ?)";
		return super.executeUpdate(sql, epcName, parentId, type);
	}

	
	
}
