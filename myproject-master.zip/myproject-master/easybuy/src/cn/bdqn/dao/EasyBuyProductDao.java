package cn.bdqn.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.bdqn.entity.EasyBuyProduct;

public class EasyBuyProductDao extends BaseDao{
	//查询全部商品信息
	public List<EasyBuyProduct> findAll() {
		List<EasyBuyProduct> easyBuyProductList=new ArrayList<>();
		String sql="SELECT `epId`,`epName`,`description`,`price`,`stock`,`epcId`,`fileName` FROM `EasyBuyProduct`";
		try {
			rs=super.executeQuery(sql);
			while(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");;
				int epcId=rs.getInt("epcId");;
				String fileName=rs.getString("fileName");
				easyBuyProductList.add(new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyProductList;
	}
	
	//查询全部商品总数
	public int getTotalCount() {
		int count=0;
		String sql="SELECT COUNT(`epId`) FROM `EasyBuyProduct`";
		try {
			rs=super.executeQuery(sql);
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return count;
	}
	
	//查询ParentId总数
	public int getTotalCountByParentId(int parentId) {
		int count=0;
		String sql="SELECT COUNT(`parentId`) FROM `EasyBuyProduct`LEFT JOIN `easybuycategory` ON EasyBuyProduct.epcId=easybuycategory.epcId WHERE `parentId`=? && `type`!=0";
		try {
			rs=super.executeQuery(sql,parentId);
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return count;
	}
	
	public List<EasyBuyProduct> findByPage(int pageNo, int pageSize) {
		List<EasyBuyProduct> pageList=new ArrayList<>();
		String sql="SELECT `epId`,`epName`,`description`,`price`,`stock`,`epcId`,`fileName` FROM `EasyBuyProduct` LIMIT ?,?";
		try {
			rs=super.executeQuery(sql,(pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");;
				int epcId=rs.getInt("epcId");;
				String fileName=rs.getString("fileName");
				pageList.add(new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return pageList;
	}
	
	
	public List<EasyBuyProduct> findParentIdByPage(int id,int pageNo, int pageSize) {
		List<EasyBuyProduct> pageList=new ArrayList<>();
		String sql="SELECT * FROM `EasyBuyProduct` LEFT JOIN `easybuycategory` ON EasyBuyProduct.epcId=easybuycategory.epcId WHERE `parentId`=? && `type`!=0 LIMIT ?,?";
		try {
			rs=super.executeQuery(sql,id,(pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");;
				int epcId=rs.getInt("epcId");;
				String fileName=rs.getString("fileName");
				pageList.add(new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return pageList;
	}
	
	public EasyBuyProduct findByEpId(int id) {
		EasyBuyProduct easyBuyProduct=null;
		String sql="SELECT `epId`,`epName`,`description`,`price`,`stock`,`epcId`,`fileName` FROM `EasyBuyProduct` WHERE `epId`=?";
		try {
			rs=super.executeQuery(sql, id);
			if(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");;
				int epcId=rs.getInt("epcId");;
				String fileName=rs.getString("fileName");
				easyBuyProduct=new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyProduct;
	}
	

	public List<EasyBuyProduct> findByEpcId(int id) {
		List<EasyBuyProduct> easyBuyProductList=new ArrayList<>();
		String sql="SELECT `epId`,`epName`,`description`,`price`,`stock`,`epcId`,`fileName` FROM `EasyBuyProduct` WHERE `epcId`=?";
		try {
			rs=super.executeQuery(sql,id);
			while(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");;
				int epcId=rs.getInt("epcId");;
				String fileName=rs.getString("fileName");
				easyBuyProductList.add(new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyProductList;
	}
	
	//大类商品信息
	public List<EasyBuyProduct> findByParentId(int id) {
		List<EasyBuyProduct> easyBuyProductList=new ArrayList<>();
		String sql="SELECT * FROM `EasyBuyProduct`LEFT JOIN `easybuycategory` ON EasyBuyProduct.epcId=easybuycategory.epcId WHERE `parentId`=? && `type`!=0";
		try {
			rs=super.executeQuery(sql,id);
			while(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");
				int epcId=rs.getInt("epcId");
				String fileName=rs.getString("fileName");
				easyBuyProductList.add(new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyProductList;
	}
	
	//修改商品信息
	public int updateProduct(String epName, String description, float price, int stock, int epcId, String fileName,
			int epId) {
		String sql="UPDATE `EasyBuyProduct` SET `epName`=?,`description`=?,`price`=?,`stock`=?,`epcId`=?,`fileName`=? WHERE `epId`=?";
		return super.executeUpdate(sql,epName,description,price,stock,epcId,fileName,epId);
	}

	public int addProduct(String epName, String description, float price, int stock, int epcId, String fileName) {
		String sql="INSERT INTO easybuyproduct (`epName`,`description`,`price`,`stock`,`epcId`,`fileName`) VALUES (?,?,?, ?,?,?);";
		return super.executeUpdate(sql,epName,description,price,stock,epcId,fileName);
	}

	public int delProduct(int epId) {
		String sql="DELETE FROM `EasyBuyProduct` WHERE `epId`=?";
		return super.executeUpdate(sql, epId);
	}
	
	//查询所有订单商品
	public List<EasyBuyProduct> findAllOrderProduct() {
		List<EasyBuyProduct> opList=new ArrayList<>();
		String sql="SELECT * FROM `EasyBuyOrder` , `EasyBuyOrderDetail` ,`EasyBuyProduct` WHERE EasyBuyOrder.eoId=EasyBuyOrderDetail.eoId AND EasyBuyOrderDetail.epId=EasyBuyProduct.epId";
		try {
			rs=super.executeQuery(sql);
			while(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");;
				int epcId=rs.getInt("epcId");;
				String fileName=rs.getString("fileName");
				opList.add(new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return opList;
	}

	public List<EasyBuyProduct> findByEoId(int eoId) {
		List<EasyBuyProduct> opList=new ArrayList<>();
		String sql="SELECT * FROM `EasyBuyOrderDetail` ,`EasyBuyProduct` WHERE  EasyBuyOrderDetail.epId=EasyBuyProduct.epId And EasyBuyOrderDetail.eoId=?";
		try {
			rs=super.executeQuery(sql,eoId);
			while(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");;
				int epcId=rs.getInt("epcId");;
				String fileName=rs.getString("fileName");
				opList.add(new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return opList;
	}

	public int updateProduct(int stock, int epId) {
		String sql="UPDATE `EasyBuyProduct` SET `stock`=? WHERE `epId`=?";
		return super.executeUpdate(sql, stock, epId);
	}

	public int getTotalCountByEpcId(int epcId) {
		int count=0;
		String sql="SELECT COUNT(`epcId`) FROM `EasyBuyProduct` WHERE `epcId`=?";
		try {
			rs=super.executeQuery(sql,epcId);
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return count;
	}

	public List<EasyBuyProduct> findEpcIdByPage(int id, int pageNo, int pageSize) {
		List<EasyBuyProduct> easyBuyProductList=new ArrayList<>();
		String sql="SELECT `epId`,`epName`,`description`,`price`,`stock`,`epcId`,`fileName` FROM `EasyBuyProduct` WHERE `epcId`=? LIMIT ?,?";
		try {
			rs=super.executeQuery(sql,id,(pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int epId=rs.getInt("epId");
				String epName=rs.getString("epName");
				String description=rs.getString("description");
				float price=rs.getFloat("price");
				int stock=rs.getInt("stock");;
				int epcId=rs.getInt("epcId");;
				String fileName=rs.getString("fileName");
				easyBuyProductList.add(new EasyBuyProduct(epId, epName, description, price, stock, epcId, fileName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyProductList;
	}
}
