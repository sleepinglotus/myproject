package cn.bdqn.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.bdqn.entity.EasyBuyOrderDetail;

public class EasyBuyOrderDetailDao extends BaseDao {

	public List<EasyBuyOrderDetail> findAll() {
		List<EasyBuyOrderDetail> detailList=new ArrayList<>();
		String sql="SELECT `eodId`,`eoId`,`epId`,`quantity`,`cost` FROM `EasyBuyOrderDetail`";
		try {
			rs=super.executeQuery(sql);
			while(rs.next()) {
				int eodId=rs.getInt("eodId");
				int eoId=rs.getInt("eoId");
				int epId=rs.getInt("epId");
				int quantity=rs.getInt("quantity");
				float cost=rs.getFloat("cost");
				detailList.add(new EasyBuyOrderDetail(eodId, eoId, epId, quantity, cost));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return detailList;
	}

	public List<EasyBuyOrderDetail> findByEoId(int id) {
		List<EasyBuyOrderDetail> detailList=new ArrayList<>();
		String sql="SELECT `eodId`,`eoId`,`epId`,`quantity`,`cost` FROM `EasyBuyOrderDetail` WHERE `eoId`=?";
		try {
			rs=super.executeQuery(sql,id);
			while(rs.next()) {
				int eodId=rs.getInt("eodId");
				int eoId=rs.getInt("eoId");
				int epId=rs.getInt("epId");
				int quantity=rs.getInt("quantity");
				float cost=rs.getFloat("cost");
				detailList.add(new EasyBuyOrderDetail(eodId, eoId, epId, quantity, cost));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return detailList;
	}

	public int addOrderDetail(int eoId, int epId, int quantity, float cost) {
		String sql="INSERT INTO `EasyBuyOrderDetail`(`eoId`,`epId`,`quantity`,`cost`)VALUES(?,?,?,?)";
		return super.executeUpdate(sql, eoId,epId,quantity,cost);
	}

}
