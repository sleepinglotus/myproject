package cn.bdqn.dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import cn.bdqn.entity.EasyBuyComment;

public class EasyBuyCommentDao extends BaseDao{

	public int getTotalCount() {
		int count=0;
		String sql="SELECT COUNT(`ecId`) FROM `EasyBuyComment`";
		try {
			rs=super.executeQuery(sql);
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		
		return count;
	}

	public List<EasyBuyComment> findByPage(int pageNo, int pageSize) {
		List<EasyBuyComment> easyBuyCommentList=new ArrayList<>();
		String sql="SELECT `ecId`,`reply`,`content`,`createTime`,`replyTime`,`nickName` FROM `EasyBuyComment` ORDER BY `createTime` DESC LIMIT ?,?";
		try {
			rs=super.executeQuery(sql, (pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int ecId=rs.getInt("ecId");
				String reply=rs.getString("reply");
				String content=rs.getString("content");
				Timestamp createTime=rs.getTimestamp("createTime");
				Timestamp replyTime=rs.getTimestamp("replyTime");
				String nickName=rs.getString("nickName");
				easyBuyCommentList.add(new EasyBuyComment(ecId, reply, content, createTime, replyTime, nickName));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyCommentList;
	}

	public int addComment(String guestContent,Timestamp createTime,String guestName,Timestamp replyTime) {
		String sql="INSERT INTO `easybuycomment` (`content`,`createTime`,`nickName`,`replyTime`) VALUES(?,?,?,?)";
		return super.executeUpdate(sql, guestContent,createTime,guestName,replyTime);
	}

	public EasyBuyComment findByEcId(int id) {
		EasyBuyComment easyBuyComment=null;
		String sql="SELECT `ecId`,`reply`,`content`,`createTime`,`replyTime`,`nickName` FROM `EasyBuyComment` WHERE `ecId`=?";
		try {
			rs=super.executeQuery(sql,id);
			while(rs.next()) {
				int ecId=rs.getInt("ecId");
				String reply=rs.getString("reply");
				String content=rs.getString("content");
				Timestamp createTime=rs.getTimestamp("createTime");
				Timestamp replyTime=rs.getTimestamp("replyTime");
				String nickName=rs.getString("nickName");
				easyBuyComment=new EasyBuyComment(ecId, reply, content, createTime, replyTime, nickName);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyComment;
	}

	public int updateComment(String replyContent,int ecId) {
		String sql="UPDATE `EasyBuyComment` SET `reply`=? WHERE `ecId`=?";
		return super.executeUpdate(sql, replyContent,ecId);
	}

	public int delComment(int ecId) {
		String sql="DELETE FROM `EasyBuyComment` WHERE `ecId`=? ";
		return super.executeUpdate(sql,ecId);
	}
	
}
