package cn.bdqn.dao;

import java.sql.Date;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;


import cn.bdqn.entity.EasyBuyUser;

public class EasyBuyUserDao extends BaseDao {

	public EasyBuyUser findByNickName(String name) {
		EasyBuyUser easyBuyUser = null;
		String sql = "SELECT `userId`,`userName`,`nickName`,`userPwd`,`userSex`,`birthday`,`identityCode`,`email`,`mobile`,`address`,`status` FROM `easyBuyUser` WHERE `nickName`=?";
		try {
			rs = super.executeQuery(sql, name);
			if (rs.next()) {
				int userId = rs.getInt("userId");
				String userName = rs.getString("userName");
				String nickName = rs.getString("nickName");
				String userPwd = rs.getString("userPwd");
				int userSex = rs.getInt("userSex");
				Date birthday = rs.getDate("birthday");
				String identityCode = rs.getString("identityCode");
				String email = rs.getString("email");
				String mobile = rs.getString("mobile");
				String address = rs.getString("address");
				int status = rs.getInt("status");
				easyBuyUser = new EasyBuyUser(userId, userName, nickName, userPwd, userSex, birthday, identityCode,
						email, mobile, address, status);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyUser;
	}

	public int addUser(String userName, String nickName, String userPwd, int userSex, Date birthday,
			String identityCode, String email, String mobile, String address, int status) {
		String sql = "INSERT INTO `EasybuyUser`(`userName`,`nickName`,`userPwd`,`userSex`,`birthday`,`identityCode`,`email`,`mobile`,`address`,`status`) VALUES(?,?,?,?,?,?,?,?,?,?)";
		return super.executeUpdate(sql, userName, nickName, userPwd, userSex, birthday, identityCode, email, mobile,
				address, status);
	}

	public List<EasyBuyUser> findAll() {
		List<EasyBuyUser> easyBuyUserList = new ArrayList<>();
		String sql = "SELECT `userId`,`userName`,`nickName`,`userPwd`,`userSex`,`birthday`,`identityCode`,`email`,`mobile`,`address`,`status` FROM `easyBuyUser`";
		try {
			rs = super.executeQuery(sql);
			while (rs.next()) {
				int userId = rs.getInt("userId");
				String userName = rs.getString("userName");
				String nickName = rs.getString("nickName");
				String userPwd = rs.getString("userPwd");
				int userSex = rs.getInt("userSex");
				Date birthday = rs.getDate("birthday");
				String identityCode = rs.getString("identityCode");
				String email = rs.getString("email");
				String mobile = rs.getString("mobile");
				String address = rs.getString("address");
				int status = rs.getInt("status");
				easyBuyUserList.add(new EasyBuyUser(userId, userName, nickName, userPwd, userSex, birthday,
						identityCode, email, mobile, address, status));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyUserList;
	}

	public int updateUser(String userName, String nickName, String userPwd, int userSex, Date birthday, String email,
			String mobile, String address) {
		String sql = "UPDATE `EasybuyUser` SET `userName`=?,`userPwd`=?,`userSex`=?,`birthday`=?,`email`=?,`mobile`=?,`address`=? WHERE `nickName`=? ";
		return super.executeUpdate(sql, userName, userPwd, userSex, birthday, email, mobile, address, nickName);
	}

	public int delUser(String nickName) {
		String sql = "DELETE FROM `EasybuyUser` WHERE `nickName`=? ";
		return super.executeUpdate(sql, nickName);
	}

	public int getTotalCount() {
		int count = 0;
		String sql = "SELECT COUNT(`userId`) FROM `EasybuyUser`";
		try {
			rs = super.executeQuery(sql);
			if (rs.next())
				count = rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			super.CloseAll(rs, pstmt, conn);
		}

		return count;
	}

	public List<EasyBuyUser> findByPage(int pageNo, int pageSize) {
		List<EasyBuyUser> easyBuyUserList = new ArrayList<>();
		String sql = "SELECT `userId`,`userName`,`nickName`,`userPwd`,`userSex`,`birthday`,`identityCode`,`email`,`mobile`,`address`,`status` FROM `easyBuyUser` LIMIT ?,?";
		try {
			rs = super.executeQuery(sql, (pageNo - 1) * pageSize, pageSize);
			while (rs.next()) {
				int userId = rs.getInt("userId");
				String userName = rs.getString("userName");
				String nickName = rs.getString("nickName");
				String userPwd = rs.getString("userPwd");
				int userSex = rs.getInt("userSex");
				Date birthday = rs.getDate("birthday");
				String identityCode = rs.getString("identityCode");
				String email = rs.getString("email");
				String mobile = rs.getString("mobile");
				String address = rs.getString("address");
				int status = rs.getInt("status");
				easyBuyUserList.add(new EasyBuyUser(userId, userName, nickName, userPwd, userSex, birthday,
						identityCode, email, mobile, address, status));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return easyBuyUserList;
	}

}
