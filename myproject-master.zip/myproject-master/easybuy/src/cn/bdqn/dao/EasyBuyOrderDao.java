package cn.bdqn.dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import cn.bdqn.entity.EasyBuyOrder;

public class EasyBuyOrderDao extends BaseDao {

	public int getTotalCount() {
		int count=0;
		String sql="SELECT COUNT(`eoId`) FROM `EasyBuyOrder`";
		try {
			rs=super.executeQuery(sql);
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return count;
	}

	public List<EasyBuyOrder> findByPage(int pageNo, int pageSize) {
		List<EasyBuyOrder> pageList=new ArrayList<>();
		String sql="SELECT * FROM `EasyBuyOrder` LIMIT ?,?";
		try {
			rs=super.executeQuery(sql, (pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int eoId=rs.getInt("eoId"); 
				int userId=rs.getInt("userId");
				String address=rs.getString("address");
				Timestamp createTime=rs.getTimestamp("createTime");
				float cost=rs.getFloat("cost"); //总价
				int status=rs.getInt("status"); //库存
				int type=rs.getInt("type");
				pageList.add(new EasyBuyOrder(eoId, userId, address, createTime, cost, status, type));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pageList;
	}

	public int getCountByEoId(int eoId) {
		int count=0;
		String sql="SELECT  COUNT(eoId) FROM `EasyBuyOrder` WHERE eoId LIKE ?";
		try {
			rs=super.executeQuery(sql,"%"+eoId+"%");
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return count;
	}

	public List<EasyBuyOrder> findByEoId(int pageNo, int pageSize, int id) {
		List<EasyBuyOrder> pageList=new ArrayList<>();
		String sql="SELECT * FROM `EasyBuyOrder` WHERE eoId LIKE ? LIMIT ?,?";
		try {
			rs=super.executeQuery(sql,"%"+id+"%",(pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int eoId=rs.getInt("eoId"); 
				int userId=rs.getInt("userId");
				String address=rs.getString("address");
				Timestamp createTime=rs.getTimestamp("createTime");
				float cost=rs.getFloat("cost"); //总价
				int status=rs.getInt("status"); //库存
				int type=rs.getInt("type");
				pageList.add(new EasyBuyOrder(eoId, userId, address, createTime, cost, status, type));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pageList;
	}

	public int getCountByNickName(String nickName) {
		int count=0;
		String sql="SELECT  COUNT(eoId) FROM `EasyBuyOrder` WHERE `userId` IN (SELECT `EasybuyUser`.userId FROM `EasybuyUser` WHERE nickName LIKE ?)";
		try {
			rs=super.executeQuery(sql,"%"+nickName+"%");
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return count;
	}

	public List<EasyBuyOrder> findByNickName(int pageNo, int pageSize, String nickName) {
		List<EasyBuyOrder> pageList=new ArrayList<>();
		String sql="SELECT  * FROM `EasyBuyOrder` WHERE `userId` IN (SELECT `EasybuyUser`.userId FROM `EasybuyUser` WHERE nickName LIKE ?) LIMIT ?,?";
		try {
			rs=super.executeQuery(sql, "%"+nickName+"%",(pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int eoId=rs.getInt("eoId"); 
				int userId=rs.getInt("userId");
				String address=rs.getString("address");
				Timestamp createTime=rs.getTimestamp("createTime");
				float cost=rs.getFloat("cost"); 
				int status=rs.getInt("status"); 
				int type=rs.getInt("type");
				pageList.add(new EasyBuyOrder(eoId, userId, address, createTime, cost, status, type));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pageList;
	}

	public int getCountByEoIdAndNickName(int eoId, String nickName) {
		int count=0;
		String sql="SELECT  COUNT(eoId) FROM `EasyBuyOrder` WHERE eoId LIKE ? And `userId` IN (SELECT `EasybuyUser`.userId FROM `EasybuyUser` WHERE nickName LIKE ?)";
		try {
			rs=super.executeQuery(sql,"%"+eoId+"%","%"+nickName+"%");
			if(rs.next())
				count=rs.getInt(1);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return count;
	}

	public List<EasyBuyOrder> findByEoIdAndNickName(int pageNo, int pageSize, int id, String nickName) {
		List<EasyBuyOrder> pageList=new ArrayList<>();
		String sql="SELECT  * FROM `EasyBuyOrder` WHERE eoId LIKE ? AND `userId` IN (SELECT `EasybuyUser`.userId FROM `EasybuyUser` WHERE nickName LIKE ?) LIMIT ?,?";
		try {
			rs=super.executeQuery(sql, "%"+id+"%", "%"+nickName+"%",(pageNo-1)*pageSize,pageSize);
			while(rs.next()) {
				int eoId=rs.getInt("eoId"); 
				int userId=rs.getInt("userId");
				String address=rs.getString("address");
				Timestamp createTime=rs.getTimestamp("createTime");
				float cost=rs.getFloat("cost"); 
				int status=rs.getInt("status"); 
				int type=rs.getInt("type");
				pageList.add(new EasyBuyOrder(eoId, userId, address, createTime, cost, status, type));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pageList;
	}

	public int updateStatus(int status, int eoId) {
		String sql="UPDATE `EasyBuyOrder` SET `status`=? WHERE `eoId`=?";
		return super.executeUpdate(sql, status, eoId);
	}

	public int addOrder(int userId, String address, Timestamp createTime, float cost, int status, int type) {
		String sql="INSERT INTO `EasyBuyOrder`(`userId`,`address`,`createTime`,`cost`,`status`,`type`)VALUES(?, ?,?,?,?,?)";
		return super.executeUpdate(sql, userId,address,createTime,cost,status,type);
	}

	public int getEpId() {
		int eoId=0;
		String sql="SELECT MAX(eoid) eoid FROM easybuyorder";
		try {
			rs=super.executeQuery(sql);
			if(rs.next()) {
				eoId=rs.getInt(1);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			super.CloseAll(rs, pstmt, conn);
		}
		return eoId;
	}

}
