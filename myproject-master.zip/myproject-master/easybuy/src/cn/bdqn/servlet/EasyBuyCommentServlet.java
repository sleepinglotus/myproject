package cn.bdqn.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.entity.EasyBuyCategory;
import cn.bdqn.entity.EasyBuyComment;
import cn.bdqn.service.EasyBuyCategoryService;
import cn.bdqn.service.EasyBuyCommentService;
import cn.bdqn.util.PageBean;


public class EasyBuyCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private EasyBuyCommentService easyBuyCommentService=new EasyBuyCommentService();
    private EasyBuyCategoryService easyBuyCategoryService=new EasyBuyCategoryService();
    
    public EasyBuyCommentServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opr=request.getParameter("opr");
		List<EasyBuyCategory> easyBuyCategoryList=easyBuyCategoryService.findAll();
		request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
		//添加留言
		if("add".equals(opr)) {
			String guestContent=request.getParameter("guestContent");
			Date date=new Date();
			Timestamp createTime=new Timestamp(date.getTime());
			Timestamp replyTime=createTime;
			String guestName=request.getParameter("guestName");
			int ret=easyBuyCommentService.addComment(guestContent,createTime,guestName,replyTime);
			if(ret>0){
				String msg="留言成功！";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher("guestbook.jsp").forward(request, response);
			}else {
				String msg="留言失败！";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher("guestbook.jsp").forward(request, response);
			}
		}
		
		//分页查询所有留言
		if("show".equals(opr)) {
			int pageNo=1;
			int pageSize=3;
			String pageNoStr=request.getParameter("pageNo");
			if(pageNoStr!=null)
				pageNo=Integer.parseInt(pageNoStr);
			PageBean<EasyBuyComment> pageBean=easyBuyCommentService.findByPage(pageNo, pageSize);
			request.setAttribute("pageBean", pageBean);
			request.getRequestDispatcher("guestbook.jsp").forward(request, response);
		}
		
		//转到留言更新页面
		if("commentModify".equals(opr)) {
			String ecIdStr=request.getParameter("ecId");
			int ecId=Integer.parseInt(ecIdStr);
			EasyBuyComment easyBuyComment=easyBuyCommentService.findByEcId(ecId);
			request.setAttribute("easyBuyComment", easyBuyComment);
			request.getRequestDispatcher("guestbook-modify.jsp").forward(request, response);
		}
		
		//更新留言
		if("update".equals(opr)) {
			String replyContent=request.getParameter("replyContent");
			String ecIdStr=request.getParameter("ecId");
			int ecId=Integer.parseInt(ecIdStr);
			int ret=easyBuyCommentService.updateComment(replyContent,ecId);
			if(ret>0) {
				request.getRequestDispatcher("manage-result.jsp").forward(request, response);
			}	
		}
		
		//删除留言
		if("del".equals(opr)) {
			String ecIdStr=request.getParameter("a");
			int ecId=Integer.parseInt(ecIdStr);
			int ret=easyBuyCommentService.delComment(ecId);
			PrintWriter out=response.getWriter();
			if(ret>0) {
				out.write("true");
			}else {
				out.write("false");
			}
			out.flush();
			out.close();
		}
		
	}

}
