package cn.bdqn.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.entity.EasyBuyProduct;
import cn.bdqn.entity.EasyBuyUser;
import cn.bdqn.entity.ShoppingCart;
import cn.bdqn.entity.ShoppingCartItem;
import cn.bdqn.service.EasyBuyProductService;
import cn.bdqn.service.EasyBuyUserService;

/**
 * Servlet implementation class ShoppingCartServlet
 */
public class ShoppingCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private EasyBuyProductService easyBuyProductService=new EasyBuyProductService();
    private EasyBuyUserService easyBuyUserService=new EasyBuyUserService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opr=request.getParameter("opr");
		
		EasyBuyUser easyBuyUser=(EasyBuyUser) request.getSession().getAttribute("easyBuyUser");
		ShoppingCart shoppingCart=(ShoppingCart) request.getSession().getAttribute("shoppingCart");
		if(shoppingCart==null)
			shoppingCart=new ShoppingCart();
		PrintWriter out=response.getWriter();
		
		List<ShoppingCartItem> userCart=new ArrayList<>();
		if("findAll".equals(opr)) {
			for(int i=0;i<shoppingCart.getItems().size();i++) {
				if(easyBuyUser.getUserId()==shoppingCart.getItems().get(i).getUser().getUserId()) {
					userCart.add(shoppingCart.getItems().get(i));
				}
			}
			request.getSession().setAttribute("shoppingCart", shoppingCart);
			request.getSession().setAttribute("userCart", userCart);
			response.sendRedirect(request.getContextPath()+"/shopping.jsp");
		}
		
		
		//加入购物车
		if("shoppingCart".equals(opr)) {
			String epIdStr=request.getParameter("epId");
			int epId=Integer.parseInt(epIdStr);
			EasyBuyProduct easyBuyProduct=easyBuyProductService.findByEpId(epId);
			int quantity=1;
			shoppingCart.addItem(easyBuyUser,easyBuyProduct, quantity);
			for(int i=0;i<shoppingCart.getItems().size();i++) {
				if(easyBuyUser.getUserId()==shoppingCart.getItems().get(i).getUser().getUserId()) {
					userCart.add(shoppingCart.getItems().get(i));
				}
			}
			request.getSession().setAttribute("shoppingCart", shoppingCart);
			request.getSession().setAttribute("userCart", userCart);
			response.sendRedirect(request.getContextPath()+"/shopping.jsp");
		}
		
		//删除商品
		if("del".equals(opr)) {
			String epIdStr=request.getParameter("epId");
			int epId=Integer.parseInt(epIdStr);
			shoppingCart.removeItem(easyBuyUser.getUserId(),epId);
			out.write("true");
		}
		
		//修改商品
		if("update".equals(opr)) {
			String epIdStr=request.getParameter("epId");
			int epId=Integer.parseInt(epIdStr);
			String numberStr=request.getParameter("number");
			int quantity=Integer.parseInt(numberStr);
			shoppingCart.modifyQuantity(easyBuyUser.getUserId(),epId, quantity);
			out.write("true");
		}

		out.flush();
		out.close();
	}

}
