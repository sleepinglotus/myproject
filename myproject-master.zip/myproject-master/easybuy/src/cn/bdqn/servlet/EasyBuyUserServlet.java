package cn.bdqn.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.bdqn.entity.EasyBuyUser;
import cn.bdqn.service.EasyBuyUserService;
import cn.bdqn.util.PageBean;

public class EasyBuyUserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	EasyBuyUserService easyBuyUserService=new EasyBuyUserService();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String opr=request.getParameter("opr");
		HttpSession session=request.getSession();
		if("login".equals(opr)){
			String code=request.getParameter("code");
			String numrand=(String) session.getAttribute("numrand");
			if(numrand.equals(code)) {
				String nickName=request.getParameter("nickName");
				String password=request.getParameter("password");
				EasyBuyUser easyBuyUser=easyBuyUserService.doLogin(nickName,password);
				if(easyBuyUser!=null){
					session.setAttribute("easyBuyUser", easyBuyUser);
					session.setMaxInactiveInterval(60*60);
					response.sendRedirect("index.jsp");
				}else{
					String msg="用户名(昵称)或密码输入错误！请重新登录！";
					request.setAttribute("msg", msg);
					request.getRequestDispatcher("login.jsp").forward(request, response);
				}
			}else {
				String msg="验证码输入错误！";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}	
		}
		if("logout".equals(opr)){
	   		session.removeAttribute("easyBuyUser");
	   		session.removeAttribute("userCart");
	   		response.sendRedirect(request.getContextPath()+"/index.jsp");
		}
		if("register".equals(opr)){
			String userName=request.getParameter("userName");
			String nickName=request.getParameter("nickName");
			String userPwd=request.getParameter("password");
			String sexStr=request.getParameter("sex");
			int userSex=0;
			if("male".equals(sexStr)){
				userSex=1;
			}
			String birthdayStr=request.getParameter("birthday");
			java.sql.Date birthday=null;
			if(null!=birthdayStr&&!"".equals(birthdayStr)){
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
				java.util.Date date = null;
				try {
					date=sdf.parse(birthdayStr);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				birthday=new java.sql.Date(date.getTime());
			}
			String identityCode=request.getParameter("identityCode");
			String email=request.getParameter("email");
			String mobile=request.getParameter("mobile");
			String address=request.getParameter("address");
			int status=0;
			int ret=easyBuyUserService.doRegister(userName,nickName,userPwd,userSex,birthday,identityCode,email,mobile,address,status);
			if(ret>0){
				EasyBuyUser easyBuyUser=easyBuyUserService.doLogin(nickName,userPwd);
				session.setAttribute("easyBuyUser", easyBuyUser);
				session.setMaxInactiveInterval(60*60);
				request.getRequestDispatcher("reg-result.jsp").forward(request, response);
			}else{
				String msg="注册失败！请重试！";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		}
		if("checkUserName".equals(opr)) {
			String nickName=request.getParameter("nickName");
			EasyBuyUser easyBuyUser=easyBuyUserService.checkUserName(nickName);
			PrintWriter out=response.getWriter();
			if(easyBuyUser!=null) {
				out.write("true");
			}else {
				out.write("false");
			}
			out.flush();
			out.close();
		}
		if("userModify".equals(opr)){
			String nickName=request.getParameter("nickName");
			EasyBuyUser easyBuyUser=easyBuyUserService.checkUserName(nickName);
			if(null!=easyBuyUser.getBirthday()) {
				java.util.Date time=new java.util.Date (easyBuyUser.getBirthday().getTime());
				Calendar cal = Calendar.getInstance();
				cal.setTime(time);
				int year=cal.get(Calendar.YEAR);
				int month=cal.get(Calendar.MONTH)+1;
				int date=cal.get(Calendar.DATE);
				request.setAttribute("year", year);
				request.setAttribute("month", month);
				request.setAttribute("date", date);
			}
			request.setAttribute("easyBuyUser", easyBuyUser);
			request.getRequestDispatcher("user-modify.jsp").forward(request, response);
		}
		if("findAll".equals(opr)){
			int pageNo=1;
			int pageSize=9;
			String pageNoStr=request.getParameter("pageNo");
			if(pageNoStr!=null)
				pageNo=Integer.parseInt(pageNoStr);
			PageBean<EasyBuyUser> pageBean=easyBuyUserService.findByPage(pageNo, pageSize);
			request.setAttribute("pageBean", pageBean);
			List<EasyBuyUser> easyBuyUserList=easyBuyUserService.findAll();
			request.setAttribute("easyBuyUserList", easyBuyUserList);
			request.getRequestDispatcher("user.jsp").forward(request, response);
		}
		if("update".equals(opr)){
			String userName=request.getParameter("userName");
			String nickName=request.getParameter("nickName");
			String userPwd=request.getParameter("passWord");
			String sexStr=request.getParameter("sex");
			int userSex=0;
			if("male".equals(sexStr)){
				userSex=1;
			}
			String birthyear=request.getParameter("birthyear");
			String birthmonth=request.getParameter("birthmonth");
			String day=request.getParameter("birthdays");
			java.sql.Date birthday=null;
			if(birthyear!=null&&birthmonth!=null&&day!=null&&!birthyear.equals("")&&!birthmonth.equals("")&&!day.equals("")) {
				String birthdayStr=birthyear+"-"+birthmonth+"-"+day;
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
					java.util.Date date = null;
					try {
						date=sdf.parse(birthdayStr);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					birthday=new java.sql.Date(date.getTime());
			}
			String email=request.getParameter("email");
			String mobile=request.getParameter("mobile");
			String address=request.getParameter("address");
			int ret=easyBuyUserService.updateUser(userName,nickName,userPwd,userSex,birthday,email,mobile,address);
			if(ret>0){
				request.getRequestDispatcher("manage-result.jsp").forward(request, response);
			}else{
				String msg="更新失败！请重试！";
				request.setAttribute("msg", msg);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}
		if("del".equals(opr)){
			String nickName=request.getParameter("a");
			int ret=easyBuyUserService.delUser(nickName);
			PrintWriter out=response.getWriter();
			if(ret>0) {
				out.write("true");
			}else {
				out.write("false");
			}
			out.flush();
			out.close();
		}
	}

}
