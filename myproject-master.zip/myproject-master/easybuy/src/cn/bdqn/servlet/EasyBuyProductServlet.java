package cn.bdqn.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import cn.bdqn.entity.EasyBuyCategory;
import cn.bdqn.entity.EasyBuyProduct;
import cn.bdqn.service.EasyBuyCategoryService;
import cn.bdqn.service.EasyBuyProductService;
import cn.bdqn.util.PageBean;


public class EasyBuyProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private EasyBuyProductService easyBuyProductService=new EasyBuyProductService();
    private EasyBuyCategoryService easyBuyCategoryService=new EasyBuyCategoryService();
    public EasyBuyProductServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opr=request.getParameter("opr");
		List<EasyBuyCategory> easyBuyCategoryList=easyBuyCategoryService.findAll();
		request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
		
		//查询商品详细信息并添加cookie
		if("findByEpId".equals(opr)) {
			String epIdStr=request.getParameter("epId");
			int epId=Integer.parseInt(epIdStr);
			EasyBuyProduct easyBuyProduct=easyBuyProductService.findByEpId(epId);
			EasyBuyCategory easyBuyCategory=easyBuyCategoryService.findByEpcId(easyBuyProduct.getEpcId());
			int parentId=easyBuyCategory.getParentId();
			Cookie cepId=null;
			Cookie[] cookies=request.getCookies();
			for (Cookie cookie : cookies) {
				if("cepId".equals(cookie.getName())) {
					cepId=cookie;
					cepId.setValue(cepId.getValue()+epIdStr+",");
					break;
				}
			}
			if(cepId==null) {
				cepId=new Cookie("cepId", epIdStr+",");
			}
			response.addCookie(cepId);
			request.setAttribute("epcName", easyBuyCategory.getEpcName());
			request.setAttribute("parentId", parentId);
			request.setAttribute("easyBuyProduct", easyBuyProduct);
			request.getRequestDispatcher("product-view.jsp").forward(request, response);
		}
		
		//后台查询所有商品
		if("findAll".equals(opr)) {
			int pageNo=1;
			int pageSize=8;
			String pageNoStr=request.getParameter("pageNo");
			if(pageNoStr!=null)
				pageNo=Integer.parseInt(pageNoStr);
			PageBean<EasyBuyProduct> pageBean=easyBuyProductService.findByPage(pageNo, pageSize);
			request.setAttribute("pageBean", pageBean);
			List<EasyBuyProduct> easyBuyProductList=easyBuyProductService.findAll();
			request.setAttribute("easyBuyProductList", easyBuyProductList);
			request.getRequestDispatcher("product.jsp").forward(request, response);
		}
		int pageNo=1;
		int pageSize=8;
		String pageNoStr=request.getParameter("pageNo");
		if(pageNoStr!=null)
			pageNo=Integer.parseInt(pageNoStr);

		if("findByEpcId".equals(opr)) {
			String epcIdStr=request.getParameter("epcId");
			int epcId=Integer.parseInt(epcIdStr);
			String parentIdStr=request.getParameter("parentId");
			int parentId=Integer.parseInt(parentIdStr);
			String epcName=request.getParameter("epcName");
			List<EasyBuyProduct> easyBuyProductList=easyBuyProductService.findByEpcId(epcId);
			PageBean<EasyBuyProduct> pageBean=easyBuyProductService.findEpcIdByPage(epcId,pageNo, pageSize);
			List<EasyBuyProduct> cpList=new ArrayList<>();
			Cookie cepId=null;
			Cookie[] cookies=request.getCookies();
			for (Cookie cookie : cookies) {
				if("cepId".equals(cookie.getName())) {
					cepId=cookie;
					break;
				}
			}
			if(cepId!=null) {
				String epIdStr=cepId.getValue();
				String[] epIdList=epIdStr.split(",");
				int end=0;
				if(epIdList.length>3) {
					end=epIdList.length-3;
				}
				for (int i = epIdList.length-1; i >= end; i--) {
					int epId=Integer.parseInt(epIdList[i]);
					EasyBuyProduct easyBuyProduct=easyBuyProductService.findByEpId(epId);
					cpList.add(easyBuyProduct);
				}
			}
			request.setAttribute("cpList", cpList);
			request.setAttribute("parentId", parentId);
			request.setAttribute("epcName", epcName);
			request.setAttribute("easyBuyProductList", easyBuyProductList);
			request.setAttribute("pageBean", pageBean);
			request.getRequestDispatcher("product-list.jsp").forward(request, response);
		}
		
		//查询每个大类下所有商品
		if("findByParentId".equals(opr)) {
			String parentIdStr=request.getParameter("parentId");
			int parentId=Integer.parseInt(parentIdStr);
			PageBean<EasyBuyProduct> pageBean=easyBuyProductService.findParentIdByPage(parentId, pageNo, pageSize);
			request.setAttribute("parentId", parentId);
			request.setAttribute("pageBean", pageBean);
			request.getRequestDispatcher("product-list.jsp").forward(request, response);
		}
		
		//分页查询每个大类下所有商品
		if("findPageByParentId".equals(opr)) {
			String parentIdStr=request.getParameter("parentId");
			int parentId=Integer.parseInt(parentIdStr);
			List<EasyBuyProduct> easyBuyProductList=easyBuyProductService.findByParentId(parentId);
			PageBean<EasyBuyProduct> pageBean=easyBuyProductService.findParentIdByPage(parentId, pageNo, pageSize);
			List<EasyBuyProduct> cpList=new ArrayList<>();
			Cookie cepId=null;
			Cookie[] cookies=request.getCookies();
			for (Cookie cookie : cookies) {
				if("cepId".equals(cookie.getName())) {
					cepId=cookie;
					break;
				}
			}
			if(cepId!=null) {
				String epIdStr=cepId.getValue();
				String[] epIdList=epIdStr.split(",");
				int end=0;
				if(epIdList.length>3) {
					end=epIdList.length-3;
				}
				for (int i = epIdList.length-1; i >= end; i--) {
					int epId=Integer.parseInt(epIdList[i]);
					EasyBuyProduct easyBuyProduct=easyBuyProductService.findByEpId(epId);
					cpList.add(easyBuyProduct);
				}
			}
			request.setAttribute("cpList", cpList);
			request.setAttribute("parentId", parentId);
			request.setAttribute("easyBuyProductList", easyBuyProductList);
			request.setAttribute("pageBean", pageBean);
			request.getRequestDispatcher("product-parentlist.jsp").forward(request, response);
		}
		
		if("productModify".equals(opr)){
			String epIdStr=request.getParameter("epId");
			int epId=Integer.parseInt(epIdStr);
			EasyBuyProduct easyBuyProduct=easyBuyProductService.findByEpId(epId);
			request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
			request.setAttribute("easyBuyProduct", easyBuyProduct);
			request.getRequestDispatcher("product-modify.jsp").forward(request, response);
		}
		
		if("addModify".equals(opr)){
			request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
			request.getRequestDispatcher("product-add.jsp").forward(request, response);
		}
		
		//更新商品信息
		if("update".equals(opr)) {
			String epIdStr=request.getParameter("epId");
			int epId=Integer.parseInt(epIdStr);
			String epName=null;
			String description=null;
			float price=0;
			int stock=0;
			String epcIdStr=request.getParameter("epcId");
			int epcId=Integer.parseInt(epcIdStr);
			String fileName=null;
			
			DiskFileItemFactory factory = new DiskFileItemFactory();
	        //创建文件核心上传组建
	        ServletFileUpload upload=new ServletFileUpload(factory);
	        
	        upload.setHeaderEncoding("UTF-8"); 
	        try {
	        	//解析请求，获取所有item
				@SuppressWarnings("unchecked")
				List<FileItem> items=upload.parseRequest(request);
				for (FileItem item : items) {
					if(item.isFormField()) {
						String name=item.getFieldName();
						String value=item.getString("UTF-8");
						switch (name) {
							case "epName":
								epName=value;
								break;
							case "description":
								description=value;
								break;
							case "price":
								price=Float.parseFloat(value);
								break;
							case "stock":
								stock=Integer.parseInt(value);
								break;
							default:
								break;
						}
					}else {
						fileName=item.getName();
						String fpath=this.getServletContext().getRealPath("/images/product");
						File toFile = new File(fpath, fileName);
						item.write(toFile);
					}	
				}
				int ret=easyBuyProductService.updateProduct(epName,description,price,stock,epcId,fileName,epId);
				if(ret>0) {
						request.getRequestDispatcher("manage-result.jsp").forward(request, response);
				}	
			} catch (FileUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if("del".equals(opr)) {
			String epIdStr=request.getParameter("a");
			int epId=Integer.parseInt(epIdStr);
			int ret=easyBuyProductService.delProduct(epId);
			PrintWriter out=response.getWriter();
			if(ret>0) {
				out.write("true");
			}else {
				out.write("false");
			}
			out.flush();
			out.close();
		}
		
		//添加商品
		if("add".equals(opr)) {
			String epName=null;
			String description=null;
			float price=0;
			int stock=0;
			int epcId=0;
			String fileName=null;
			DiskFileItemFactory factory = new DiskFileItemFactory();
	        ServletFileUpload upload=new ServletFileUpload(factory);
	        upload.setHeaderEncoding("UTF-8"); 
	        try {
				@SuppressWarnings("unchecked")
				List<FileItem> items=upload.parseRequest(request);
				for (FileItem item : items) {
					if(item.isFormField()) {
						String name=item.getFieldName();
						String value=item.getString("UTF-8");
						switch (name) {
							case "epName":
								epName=value;
								break;
							case "description":
								description=value;
								break;
							case "price":
								price=Float.parseFloat(value);
								break;
							case "parentId":
								epcId=Integer.parseInt(value);
								break;
							case "stock":
								stock=Integer.parseInt(value);
								break;
							default:
								break;
						}
					}else {
						fileName=item.getName();
						String fpath=this.getServletContext().getRealPath("/images/product");
						File toFile = new File(fpath, fileName);
						item.write(toFile);
					}	
				}
				//System.out.println(epId+","+epName+","+description+","+price+","+stock+","+epcId+","+fileName);

				int ret=easyBuyProductService.addProduct(epName, description, price, stock, epcId, fileName);
				if(ret>0) {
					request.getRequestDispatcher("manage-result.jsp").forward(request, response);
				}	
			} catch (FileUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	}

}
