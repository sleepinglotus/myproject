package cn.bdqn.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.entity.EasyBuyCategory;
import cn.bdqn.entity.EasyBuyNews;
import cn.bdqn.entity.EasyBuyProduct;
import cn.bdqn.entity.EasyBuyUser;
import cn.bdqn.entity.ShoppingCart;
import cn.bdqn.entity.ShoppingCartItem;
import cn.bdqn.service.EasyBuyCategoryService;
import cn.bdqn.service.EasyBuyNewsService;
import cn.bdqn.service.EasyBuyProductService;
import cn.bdqn.util.PageBean;

public class IndexServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private EasyBuyCategoryService easyBuyCategoryService=new EasyBuyCategoryService();
	private EasyBuyNewsService easyBuyNewsService=new EasyBuyNewsService();
	private EasyBuyProductService easyBuyProductService=new EasyBuyProductService();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//分页查询全部商品
		int pageNo=1;
		int pageSize=8;
		String pageNoStr=request.getParameter("pageNo");
		if(pageNoStr!=null)
			pageNo=Integer.parseInt(pageNoStr);
		PageBean<EasyBuyProduct> pageBean=easyBuyProductService.findByPage(pageNo, pageSize);
		request.setAttribute("pageBean", pageBean);
		
		List<EasyBuyNews> easyBuyNewsList=easyBuyNewsService.findTen();
		request.setAttribute("easyBuyNewsList", easyBuyNewsList);
		
		List<EasyBuyCategory> easyBuyCategoryList=easyBuyCategoryService.findAll();
		request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
		
		//最近浏览
		List<EasyBuyProduct> cpList=new ArrayList<>();
		Cookie cepId=null;
		Cookie[] cookies=request.getCookies();
		for (Cookie cookie : cookies) {
			if("cepId".equals(cookie.getName())) {
				cepId=cookie;
				break;
			}
		}
		if(cepId!=null) {
			String epIdStr=cepId.getValue();
			String[] epIdList=epIdStr.split(",");
			int end=0;
			if(epIdList.length>3) {
				end=epIdList.length-3;
			}
			for (int i = epIdList.length-1; i >= end; i--) {
				int epId=Integer.parseInt(epIdList[i]);
				EasyBuyProduct easyBuyProduct=easyBuyProductService.findByEpId(epId);
				cpList.add(easyBuyProduct);
			}
		}
		request.setAttribute("cpList", cpList);
		
		ShoppingCart shoppingCart=(ShoppingCart) request.getSession().getAttribute("shoppingCart");
		EasyBuyUser easyBuyUser=(EasyBuyUser) request.getSession().getAttribute("easyBuyUser");
		if(shoppingCart!=null&&easyBuyUser!=null) {
			List<ShoppingCartItem> userCart=new ArrayList<>();;
			for(int i=0;i<shoppingCart.getItems().size();i++) {
				if(easyBuyUser.getUserId()==shoppingCart.getItems().get(i).getUser().getUserId()) {
					userCart.add(shoppingCart.getItems().get(i));
				}
			}
			request.getSession().setAttribute("userCart", userCart);
		}
		
		
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
	}

}
