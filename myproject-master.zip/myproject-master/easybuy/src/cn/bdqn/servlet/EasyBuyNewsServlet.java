package cn.bdqn.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.service.EasyBuyCategoryService;
import cn.bdqn.service.EasyBuyNewsService;
import cn.bdqn.util.PageBean;
import cn.bdqn.entity.EasyBuyCategory;
import cn.bdqn.entity.EasyBuyNews;

public class EasyBuyNewsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private EasyBuyNewsService easyBuyNewsService=new EasyBuyNewsService();
    private EasyBuyCategoryService easyBuyCategoryService=new EasyBuyCategoryService();
    public EasyBuyNewsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opr=request.getParameter("opr");
		List<EasyBuyCategory> easyBuyCategoryList=easyBuyCategoryService.findAll();
		request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
		if("findAll".equals(opr)) {
			List<EasyBuyNews> easyBuyNewsList=easyBuyNewsService.findTen();
			request.setAttribute("easyBuyNewsList", easyBuyNewsList);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		if("findByEnId".equals(opr)) {
			String enIdStr=request.getParameter("enId");
			int enId=Integer.parseInt(enIdStr);
			EasyBuyNews easyBuyNews=easyBuyNewsService.findByTitle(enId);
			request.setAttribute("easyBuyNews", easyBuyNews);
			request.getRequestDispatcher("news-view.jsp").forward(request, response);
		}
		if("show".equals(opr)) {
			int pageNo=1;
			int pageSize=9;
			String pageNoStr=request.getParameter("pageNo");
			if(pageNoStr!=null)
				pageNo=Integer.parseInt(pageNoStr);
			PageBean<EasyBuyNews> pageBean=easyBuyNewsService.findByPage(pageNo, pageSize);
			request.setAttribute("pageBean", pageBean);
			request.getRequestDispatcher("news.jsp").forward(request, response);
		}
		
		if("add".equals(opr)) {
			String title=request.getParameter("title");
			String content=request.getParameter("content");
			Date date=new Date();
			Timestamp createTime=new Timestamp(date.getTime());
			int ret=easyBuyNewsService.addNews(title,content,createTime);
			if(ret>0) {
				request.getRequestDispatcher("manage-result.jsp").forward(request, response);
			}
		}
		if("newsModify".equals(opr)) {
			String enIdStr=request.getParameter("enId");
			int enId=Integer.parseInt(enIdStr);
			EasyBuyNews easyBuyNews=easyBuyNewsService.findByEnId(enId);
			request.setAttribute("easyBuyNews", easyBuyNews);
			request.getRequestDispatcher("news-modify.jsp").forward(request, response);
		}
		if("update".equals(opr)) {
			String enIdStr=request.getParameter("enId");
			int ecId=Integer.parseInt(enIdStr);
			String title=request.getParameter("title");
			String content=request.getParameter("content");
			Date date=new Date();
			Timestamp createTime=new Timestamp(date.getTime());
			int ret=easyBuyNewsService.updateNews(title,content,createTime,ecId);
			if(ret>0) {
				request.getRequestDispatcher("manage-result.jsp").forward(request, response);
			}
		}
		if("del".equals(opr)) {
			String enIdStr=request.getParameter("a");
			int enId=Integer.parseInt(enIdStr);
			int ret=easyBuyNewsService.delNews(enId);
			PrintWriter out=response.getWriter();
			if(ret>0) {
				out.write("true");
			}else {
				out.write("false");
			}
			out.flush();
			out.close();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
