package cn.bdqn.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.entity.EasyBuyCategory;
import cn.bdqn.service.EasyBuyCategoryService;
import cn.bdqn.util.PageBean;

public class EasyBuyCategoryServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private EasyBuyCategoryService easyBuyCategoryService=new EasyBuyCategoryService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String opr=request.getParameter("opr");
		if("findAll".equals(opr)) {
			List<EasyBuyCategory> easyBuyCategoryList=easyBuyCategoryService.findAll();
			request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		
		//分页查询所有
		if("findAllByPage".equals(opr)) {
			int pageNo=1;
			int pageSize=8;
			String pageNoStr=request.getParameter("pageNo");
			if(pageNoStr!=null)
				pageNo=Integer.parseInt(pageNoStr);
			PageBean<EasyBuyCategory> pageBean=easyBuyCategoryService.findByPage(pageNo, pageSize);
			List<EasyBuyCategory> easyBuyCategoryList=easyBuyCategoryService.findAll();
			request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
			request.setAttribute("pageBean", pageBean);
			request.getRequestDispatcher("productClass.jsp").forward(request, response);
		}
		if("categoryModify".equals(opr)) {
			String epcIdStr=request.getParameter("epcId");
			int epcId=Integer.parseInt(epcIdStr);
			EasyBuyCategory easyBuyCategory=easyBuyCategoryService.findByEpcId(epcId);
			List<EasyBuyCategory> easyBuyCategoryList=easyBuyCategoryService.findAll();
			request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
			request.setAttribute("easyBuyCategory", easyBuyCategory);
			request.getRequestDispatcher("productClass-modify.jsp").forward(request, response);
		}
		
		//修改
		if("update".equals(opr)) {
			String epcIdStr=request.getParameter("epcId");
			int epcId=Integer.parseInt(epcIdStr);
			String epcName=request.getParameter("epcName");
			String parentIdStr=request.getParameter("parentId");
			int parentId=Integer.parseInt(parentIdStr);
			int type=1;
			if(parentId==0) {
				type=0;
				int count=easyBuyCategoryService.getCountByType(type);
				parentId=count+1;
			}
			int ret=easyBuyCategoryService.updateCategory(epcName,parentId,type,epcId);
			if(ret>0) {
				request.getRequestDispatcher("manage-result.jsp").forward(request, response);
			}
				
		}
		
		//删除
		if("del".equals(opr)) {
			String epcIdStr=request.getParameter("a");
			int epcId=Integer.parseInt(epcIdStr);
			int ret=easyBuyCategoryService.delCategory(epcId);
			PrintWriter out=response.getWriter();
			if(ret>0) {
				out.write("true");
			}else {
				out.write("false");
			}
			out.flush();
			out.close();
		}
		if("addModify".equals(opr)) {
			List<EasyBuyCategory> easyBuyCategoryList=easyBuyCategoryService.findAll();
			request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
			request.getRequestDispatcher("productClass-add.jsp").forward(request, response);
		}
		
		
		if("add".equals(opr)) {
			String epcName=request.getParameter("epcName");
			String parentIdStr=request.getParameter("parentId");
			int parentId=Integer.parseInt(parentIdStr);
			int type=1;
			if(parentId==0) {
				type=0;
				int count=easyBuyCategoryService.getCountByType(type);
				parentId=count+1;
			}
			int ret=easyBuyCategoryService.addCategory(epcName,parentId,type);
			if(ret>0) {
				request.getRequestDispatcher("manage-result.jsp").forward(request, response);
			}
		}
	}

}
