package cn.bdqn.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.entity.EasyBuyCategory;
import cn.bdqn.entity.EasyBuyOrder;
import cn.bdqn.entity.EasyBuyOrderDetail;
import cn.bdqn.entity.EasyBuyProduct;
import cn.bdqn.entity.EasyBuyUser;
import cn.bdqn.entity.ShoppingCart;
import cn.bdqn.entity.ShoppingCartItem;
import cn.bdqn.service.EasyBuyCategoryService;
import cn.bdqn.service.EasyBuyOrderDetailService;
import cn.bdqn.service.EasyBuyOrderService;
import cn.bdqn.service.EasyBuyProductService;
import cn.bdqn.service.EasyBuyUserService;
import cn.bdqn.util.PageBean;

/**
 * Servlet implementation class EasyBuyOrderServlet
 */
public class EasyBuyOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private EasyBuyOrderService easyBuyOrderService = new EasyBuyOrderService();
	private EasyBuyOrderDetailService easyBuyOrderDetailService = new EasyBuyOrderDetailService();
	private EasyBuyProductService easyBuyProductService = new EasyBuyProductService();
	private EasyBuyUserService easyBuyUserService = new EasyBuyUserService();
	private EasyBuyCategoryService easyBuyCategoryService = new EasyBuyCategoryService();

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opr = request.getParameter("opr");
		// 分页查询所有订单
		if ("findAllByPage".equals(opr)) {
			int pageNo = 1;
			int pageSize = 2;
			String pageNoStr = request.getParameter("pageNo");
			if (pageNoStr != null)
				pageNo = Integer.parseInt(pageNoStr);
			PageBean<EasyBuyOrder> pageBean = easyBuyOrderService.findAllByPage(pageNo, pageSize);
			List<EasyBuyOrderDetail> detailList = easyBuyOrderDetailService.findAll();
			List<EasyBuyProduct> opList = easyBuyProductService.findAllOrderProduct();
			request.setAttribute("pageBean", pageBean);
			request.setAttribute("detailList", detailList);
			request.setAttribute("opList", opList);
			request.getRequestDispatcher("order.jsp").forward(request, response);
		}
		if ("findByEoIdOrNickName".equals(opr)) {
			int pageNo = 1;
			int pageSize = 2;
			String pageNoStr = request.getParameter("pageNo");
			if (pageNoStr != null)
				pageNo = Integer.parseInt(pageNoStr);
			String nickName = request.getParameter("userName");
			String eoIdStr = request.getParameter("entityId");
			PageBean<EasyBuyOrder> pageBean = null;
			List<EasyBuyOrderDetail> detailList = null;
			List<EasyBuyProduct> opList = null;
			if (eoIdStr != null && !eoIdStr.equals("") && (nickName == null || nickName.equals(""))) {
				int eoId = Integer.parseInt(eoIdStr);
				pageBean = easyBuyOrderService.findByEoId(pageNo, pageSize, eoId);
				detailList = easyBuyOrderDetailService.findAll();
				opList = easyBuyProductService.findAllOrderProduct();
				request.setAttribute("eoId", eoId);
			} else if (eoIdStr != null && !eoIdStr.equals("") && nickName != null && !nickName.equals("")) {
				int eoId = Integer.parseInt(eoIdStr);
				pageBean = easyBuyOrderService.findByEoIdAndNickName(pageNo, pageSize, eoId, nickName);
				detailList = easyBuyOrderDetailService.findAll();
				opList = easyBuyProductService.findAllOrderProduct();
				request.setAttribute("eoId", eoId);
				request.setAttribute("nickName", nickName);
			} else {
				pageBean = easyBuyOrderService.findByNickName(pageNo, pageSize, nickName);
				detailList = easyBuyOrderDetailService.findAll();
				opList = easyBuyProductService.findAllOrderProduct();
				request.setAttribute("nickName", nickName);
			}
			request.setAttribute("pageBean", pageBean);
			request.setAttribute("detailList", detailList);
			request.setAttribute("opList", opList);
			request.getRequestDispatcher("order-search.jsp").forward(request, response);

		}
		
		//修改订单状态
		if ("update".equals(opr)) {
			String eoIdStr = request.getParameter("eoId");
			int eoId = Integer.parseInt(eoIdStr);
			String statusStr = request.getParameter("status");
			int status = Integer.parseInt(statusStr);
			int ret = easyBuyOrderService.updateStatus(status, eoId);
			PrintWriter out = response.getWriter();
			if (ret > 0) {
				out.write("true");
			} else {
				out.write("false");
			}
			out.flush();
			out.close();
		}

		// 清空购物车跳转结账页面
		if ("goPayAll".equals(opr)) {
			List<EasyBuyCategory> easyBuyCategoryList = easyBuyCategoryService.findAll();
			request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
			String totalCost = request.getParameter("totalCost");
			// System.out.println(totalCost);
			request.setAttribute("totalCost", totalCost);
			request.getRequestDispatcher("address.jsp").forward(request, response);
		}

		if ("payAll".equals(opr)) {
			String nickName = request.getParameter("nickName");
			EasyBuyUser easyBuyUser = easyBuyUserService.checkUserName(nickName);
			int userId = easyBuyUser.getUserId();
			String address = request.getParameter("address");
			Date date = new Date();
			Timestamp createTime = new Timestamp(date.getTime());
			String typeStr = request.getParameter("type");
			int type = Integer.parseInt(typeStr);
			int status = 1;
			EasyBuyProduct easyBuyProduct =null;
			ShoppingCart shoppingCart = (ShoppingCart) request.getSession().getAttribute("shoppingCart");
			List<ShoppingCartItem> userCart=(List<ShoppingCartItem>) request.getSession().getAttribute("userCart");
			float totalCost=shoppingCart.getTotalCost(userId);
			int eoId = easyBuyOrderService.addOrderAndGetEoId(userId, address, createTime, totalCost, status, type);
			for (int i = 0; i < userCart.size(); i++) {
				int epId = userCart.get(i).getProduct().getEpId();
				easyBuyProduct = easyBuyProductService.findByEpId(epId);
				float cost = easyBuyProduct.getPrice();
				int stock = easyBuyProduct.getStock();
				int quantity = userCart.get(i).getQuantity();
				if(stock>=quantity) {
					int ret = easyBuyOrderDetailService.addOrderDetail(eoId, epId, quantity, cost);
					if (ret > 0) {
						int newStock = stock - quantity;
						easyBuyProductService.updateProduct(newStock, epId);	
					}
				}
				shoppingCart.removeItem(userId, epId);
			}
			userCart.clear();
			request.getRequestDispatcher("shopping-result.jsp").forward(request, response);
		}

		// 直接购买跳转传参
		if ("goPay".equals(opr)) {
			List<EasyBuyCategory> easyBuyCategoryList = easyBuyCategoryService.findAll();
			request.setAttribute("easyBuyCategoryList", easyBuyCategoryList);
			String epId = request.getParameter("epId");
			request.setAttribute("epId", epId);
			request.getRequestDispatcher("address.jsp").forward(request, response);
		}
		
		// 单独购买结算
		if ("payByEpId".equals(opr)) {
			String epIdStr = request.getParameter("epId");
			int epId = Integer.parseInt(epIdStr);
			String nickName = request.getParameter("nickName");
			EasyBuyUser easyBuyUser = easyBuyUserService.checkUserName(nickName);
			int userId = easyBuyUser.getUserId();
			// 获取地址
			String address = request.getParameter("address");
			Date date = new Date();
			Timestamp createTime = new Timestamp(date.getTime());
			// 获取支付方式
			String typeStr = request.getParameter("type");
			int type = Integer.parseInt(typeStr);
			EasyBuyProduct easyBuyProduct = easyBuyProductService.findByEpId(epId);
			float cost = easyBuyProduct.getPrice();
			int stock = easyBuyProduct.getStock();
			int status = 1;
			int eoId = easyBuyOrderService.addOrderAndGetEoId(userId, address, createTime, cost, status, type);
			if (eoId > 0) {
				int quantity = 1;
				int ret = easyBuyOrderDetailService.addOrderDetail(eoId, epId, quantity, cost);
				if (ret > 0) {
					int newStock = stock - quantity;
					int ret2 = easyBuyProductService.updateProduct(newStock, epId);
					if (ret2 > 0)
						request.getRequestDispatcher("shopping-result.jsp").forward(request, response);
				}
			}
		}
	}
}
