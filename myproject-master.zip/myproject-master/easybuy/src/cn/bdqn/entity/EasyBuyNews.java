package cn.bdqn.entity;

import java.sql.Timestamp;

public class EasyBuyNews {
	private int enId;
	private String title;
	private String content;
	private Timestamp createTime;
	public int getEnId() {
		return enId;
	}
	public void setEnId(int enId) {
		this.enId = enId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public EasyBuyNews() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EasyBuyNews(int enId, String title, String content, Timestamp createTime) {
		super();
		this.enId = enId;
		this.title = title;
		this.content = content;
		this.createTime = createTime;
	}
}
