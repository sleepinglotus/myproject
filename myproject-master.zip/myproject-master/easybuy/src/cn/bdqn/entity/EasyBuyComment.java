package cn.bdqn.entity;

import java.sql.Timestamp;

public class EasyBuyComment {
	private int ecId;
	private String reply;
	private String content;
	private Timestamp createTime;
	private Timestamp replyTime;
	private String nickName;
	public int getEcId() {
		return ecId;
	}
	public void setEcId(int ecId) {
		this.ecId = ecId;
	}
	public String getReply() {
		return reply;
	}
	public void setReply(String reply) {
		this.reply = reply;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public Timestamp getReplyTime() {
		return replyTime;
	}
	public void setReplyTime(Timestamp replyTime) {
		this.replyTime = replyTime;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public EasyBuyComment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EasyBuyComment(int ecId, String reply, String content,
			Timestamp createTime, Timestamp replyTime, String nickName) {
		super();
		this.ecId = ecId;
		this.reply = reply;
		this.content = content;
		this.createTime = createTime;
		this.replyTime = replyTime;
		this.nickName = nickName;
	}
}
