package cn.bdqn.entity;

import java.io.Serializable;

public class EasyBuyProduct implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//商品表
	private int epId;
	private String epName;
	private String description;
	private float price;
	private int stock;
	private int epcId;
	private String fileName;
	public int getEpId() {
		return epId;
	}
	public void setEpId(int epId) {
		this.epId = epId;
	}
	public String getEpName() {
		return epName;
	}
	public void setEpName(String epName) {
		this.epName = epName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public int getEpcId() {
		return epcId;
	}
	public void setEpcId(int epcId) {
		this.epcId = epcId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public EasyBuyProduct() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EasyBuyProduct(int epId, String epName, String description,
			float price, int stock, int epcId, String fileName) {
		super();
		this.epId = epId;
		this.epName = epName;
		this.description = description;
		this.price = price;
		this.stock = stock;
		this.epcId = epcId;
		this.fileName = fileName;
	}
}
