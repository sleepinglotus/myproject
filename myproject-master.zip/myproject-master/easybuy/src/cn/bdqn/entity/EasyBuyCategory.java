package cn.bdqn.entity;



public class EasyBuyCategory {
	// 商品分类
	private int epcId;
	private String epcName;
	private int parentId;
	private int type;

	public EasyBuyCategory(int epcId, String epcName, int parentId, int type) {
		super();
		this.epcId = epcId;
		this.epcName = epcName;
		this.parentId = parentId;
		this.type = type;
	}

	public EasyBuyCategory() {
		super();
	}

	public int getEpcId() {
		return epcId;
	}

	public void setEpcId(int epcId) {
		this.epcId = epcId;
	}

	public String getEpcName() {
		return epcName;
	}

	public void setEpcName(String epcName) {
		this.epcName = epcName;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

/*	public static void main(String[] args) {
		String uuid=UUID.randomUUID().toString().replace("-", "").toLowerCase();
		System.out.println(uuid);
	}*/
}
