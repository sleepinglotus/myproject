package cn.bdqn.entity;

public class EasyBuyOrderDetail {
	private int eodId;
	private int eoId; 	//订单编号
	private int epId;	//商品编号
	private int quantity; //数量
	private float cost; 
	public int getEodId() {
		return eodId;
	}
	public void setEodId(int eodId) {
		this.eodId = eodId;
	}
	public int getEoId() {
		return eoId;
	}
	public void setEoId(int eoId) {
		this.eoId = eoId;
	}
	public int getEpId() {
		return epId;
	}
	public void setEpId(int epId) {
		this.epId = epId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public EasyBuyOrderDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EasyBuyOrderDetail(int eodId, int eoId, int epId, int quantity,
			float cost) {
		super();
		this.eodId = eodId;
		this.eoId = eoId;
		this.epId = epId;
		this.quantity = quantity;
		this.cost = cost;
	}
}
