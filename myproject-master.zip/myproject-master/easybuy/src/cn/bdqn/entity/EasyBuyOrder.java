package cn.bdqn.entity;

import java.sql.Timestamp;

public class EasyBuyOrder {
	private int eoId; //订单编号
	private int userId;
	private String address;
	private Timestamp createTime;
	private float cost; //总价
	private int status; //库存
	private int type; //订单状态
	public int getEoId() {
		return eoId;
	}
	public void setEoId(int eoId) {
		this.eoId = eoId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public EasyBuyOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EasyBuyOrder(int eoId, int userId, String address,
			Timestamp createTime, float cost, int status, int type) {
		super();
		this.eoId = eoId;
		this.userId = userId;
		this.address = address;
		this.createTime = createTime;
		this.cost = cost;
		this.status = status;
		this.type = type;
	}
}
