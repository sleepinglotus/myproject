﻿package cn.bdqn.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShoppingCart implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public List<ShoppingCartItem> items = new ArrayList<ShoppingCartItem>();	

	//获取购物车中所有商品
	public List<ShoppingCartItem> getItems() {
		return items;
	}	
	//添加一项
	public void addItem(EasyBuyUser user,EasyBuyProduct product, int quantity) {
		for(int i=0;i<items.size();i++){
			//判断购物车中是否已有此商品，如果有则累计数量
			if(items.get(i).getUser().getUserId()==user.getUserId()&&items.get(i).getProduct().getEpId()==product.getEpId()){
				items.get(i).setQuantity(items.get(i).getQuantity()+quantity);;
				return;
			}
		}
		items.add(new ShoppingCartItem(user,product, quantity));
	}

	//移除一项
	public void removeItem(int userId,int epId) {
		int index=-1;
		for(int i=0;i<items.size();i++){
			//判断购物车中是否已有此商品，如果有则累计数量
			if(items.get(i).getUser().getUserId()==userId&&items.get(i).getProduct().getEpId()==epId){
				index=i;
				break;
			}
		}
		items.remove(index);
	}

	//修改数量
	public void modifyQuantity(int userId,int epId, int quantity) {
		int index=-1;
		for(int i=0;i<items.size();i++){
			//判断购物车中是否已有此商品，如果有则累计数量
			if(items.get(i).getUser().getUserId()==userId&&items.get(i).getProduct().getEpId()==epId){
				index=i;
				break;
			}
		}
		items.get(index).setQuantity(quantity);
	}

	//计算总价格
	public float getTotalCost(int userId) {
		float sum = 0;
		for (int i=0;i<items.size();i++) {
			if(items.get(i).getUser().getUserId()==userId) {
				sum = sum + items.get(i).getCost();
			}
		}
		return sum;
	}

}
