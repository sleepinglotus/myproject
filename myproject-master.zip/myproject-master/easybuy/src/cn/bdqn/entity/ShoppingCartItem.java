﻿package cn.bdqn.entity;

import java.io.Serializable;

public class ShoppingCartItem implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private EasyBuyProduct product;//商品
	private int quantity;//数量
	private float cost;//价格
	private EasyBuyUser user;//用户
	
	
	public EasyBuyUser getUser() {
		return user;
	}

	public void setUser(EasyBuyUser user) {
		this.user = user;
	}

	public ShoppingCartItem(EasyBuyUser user,EasyBuyProduct product, int quantity) {
		this.user=user;
		this.product = product;
		this.quantity = quantity;
		this.cost = product.getPrice() * quantity;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
		this.cost = product.getPrice() * quantity;
	}

	public EasyBuyProduct getProduct() {
		return product;
	}

	public float getCost() {
		return cost;
	}

	public void setProduct(EasyBuyProduct product) {
		this.product = product;
	}

}
