package cn.bdqn.service;

import java.util.List;

import cn.bdqn.dao.EasyBuyProductDao;
import cn.bdqn.entity.EasyBuyProduct;
import cn.bdqn.util.PageBean;

public class EasyBuyProductService {
	private EasyBuyProductDao easyBuyProductDao = new EasyBuyProductDao();
	public List<EasyBuyProduct> findAll(){
		return easyBuyProductDao.findAll();
	}
	//后台全部商品分页
	public PageBean<EasyBuyProduct> findByPage(int pageNo,int pageSize){
		
		PageBean<EasyBuyProduct> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyProductDao.getTotalCount();
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyProduct> pageList=easyBuyProductDao.findByPage(pageBean.getPageNo(),pageBean.getPageSize());
		pageBean.setPageList(pageList);
		return pageBean;
	}
	
	//根据商品ParentId分页
	public PageBean<EasyBuyProduct> findParentIdByPage(int parentId,int pageNo,int pageSize){
		PageBean<EasyBuyProduct> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyProductDao.getTotalCountByParentId(parentId);
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyProduct> pageList=easyBuyProductDao.findParentIdByPage(parentId, pageBean.getPageNo(),pageBean.getPageSize());
		pageBean.setPageList(pageList);
		return pageBean;
	}
	
	public EasyBuyProduct findByEpId(int epId) {
		return easyBuyProductDao.findByEpId(epId);
	}

	public List<EasyBuyProduct> findByEpcId(int epcId) {
		// TODO Auto-generated method stub
		return easyBuyProductDao.findByEpcId(epcId);
	}

	public List<EasyBuyProduct> findByParentId(int parentId) {
		// TODO Auto-generated method stub
		return easyBuyProductDao.findByParentId(parentId);
	}
	public int updateProduct(String epName, String description, float price, int stock, int epcId, String fileName,
			int epId) {
		return easyBuyProductDao.updateProduct(epName,description,price,stock,epcId,fileName,epId);
	}
	public int addProduct(String epName, String description, float price, int stock, int epcId, String fileName) {
		// TODO Auto-generated method stub
		return easyBuyProductDao.addProduct(epName,description,price,stock,epcId,fileName);
	}
	public int delProduct(int epId) {
		// TODO Auto-generated method stub
		return easyBuyProductDao.delProduct(epId);
	}
	public List<EasyBuyProduct> findAllOrderProduct() {
		// TODO Auto-generated method stub
		return easyBuyProductDao.findAllOrderProduct();
	}
	public List<EasyBuyProduct> findByEoId(int eoId) {
		// TODO Auto-generated method stub
		return easyBuyProductDao.findByEoId(eoId);
	}
	public int updateProduct(int stock, int epId) {
		return easyBuyProductDao.updateProduct(stock, epId);
	}
	public PageBean<EasyBuyProduct> findEpcIdByPage(int epcId, int pageNo, int pageSize) {
		PageBean<EasyBuyProduct> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyProductDao.getTotalCountByEpcId(epcId);
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyProduct> pageList=easyBuyProductDao.findEpcIdByPage(epcId, pageBean.getPageNo(),pageBean.getPageSize());
		pageBean.setPageList(pageList);
		return pageBean;
	}
}
