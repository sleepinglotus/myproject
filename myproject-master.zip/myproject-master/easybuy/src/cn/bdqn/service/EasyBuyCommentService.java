package cn.bdqn.service;

import java.sql.Timestamp;
import java.util.List;

import cn.bdqn.dao.EasyBuyCommentDao;
import cn.bdqn.entity.EasyBuyComment;
import cn.bdqn.util.PageBean;

public class EasyBuyCommentService {
	private EasyBuyCommentDao easyBuyCommentDao=new EasyBuyCommentDao();

	public PageBean<EasyBuyComment> findByPage(int pageNo, int pageSize) {
		PageBean<EasyBuyComment> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyCommentDao.getTotalCount();
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyComment> pageList=easyBuyCommentDao.findByPage(pageBean.getPageNo(),pageBean.getPageSize());
		pageBean.setPageList(pageList);
		return pageBean;
	}

	public int addComment(String guestContent,Timestamp createTime,String guestName,Timestamp replyTime) {
		return easyBuyCommentDao.addComment(guestContent,createTime,guestName,replyTime);
	}


	public int updateComment(String replyContent,int ecId) {
		return easyBuyCommentDao.updateComment(replyContent,ecId);
	}

	public int delComment(int ecId) {
		return easyBuyCommentDao.delComment(ecId);
	}

	public EasyBuyComment findByEcId(int ecId) {
		return easyBuyCommentDao.findByEcId(ecId);
	}
}
