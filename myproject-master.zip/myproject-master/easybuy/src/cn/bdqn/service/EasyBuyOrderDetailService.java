package cn.bdqn.service;

import java.util.List;

import cn.bdqn.dao.EasyBuyOrderDetailDao;
import cn.bdqn.entity.EasyBuyOrderDetail;

public class EasyBuyOrderDetailService {
	
	private EasyBuyOrderDetailDao easyBuyOrderDetailDao=new EasyBuyOrderDetailDao();
	
	public List<EasyBuyOrderDetail> findAll() {
		return easyBuyOrderDetailDao.findAll();
	}

	public List<EasyBuyOrderDetail> findByEoId(int eoId) {
		return easyBuyOrderDetailDao.findByEoId(eoId);
	}

	public int addOrderDetail(int eoId, int epId, int quantity, float cost) {
		return easyBuyOrderDetailDao.addOrderDetail(eoId,epId,quantity,cost);
	}

}
