package cn.bdqn.service;

import java.sql.Date;
import java.util.List;

import cn.bdqn.dao.EasyBuyUserDao;
import cn.bdqn.entity.EasyBuyUser;
import cn.bdqn.util.PageBean;

public class EasyBuyUserService {
	private EasyBuyUserDao easyBuyUserDao=new EasyBuyUserDao();
	public EasyBuyUser doLogin(String nickName, String password) {
		EasyBuyUser easyBuyUser=easyBuyUserDao.findByNickName(nickName);
		if(null!=easyBuyUser&&easyBuyUser.getUserPwd().equals(password)){
			return easyBuyUser;
		}else{
			return null;
		}
	}
	public int doRegister(String userName, String nickName,String userPwd, int userSex, Date birthday, String identityCode,String email, String mobile, String address, int status) {
		return easyBuyUserDao.addUser(userName,nickName,userPwd,userSex,birthday,identityCode,email,mobile,address,status);
	}
	public EasyBuyUser checkUserName(String nickName) {
		return easyBuyUserDao.findByNickName(nickName);
	}
	public List<EasyBuyUser> findAll() {
		return easyBuyUserDao.findAll();
	}
	public int updateUser(String userName, String nickName,String userPwd, int userSex, Date birthday,String email, String mobile, String address) {
		return easyBuyUserDao.updateUser(userName,nickName,userPwd,userSex,birthday,email,mobile,address);
	}
	public int delUser(String nickName) {
		
		return easyBuyUserDao.delUser(nickName);
	}
	public PageBean<EasyBuyUser> findByPage(int pageNo, int pageSize) {
		PageBean<EasyBuyUser> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyUserDao.getTotalCount();
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyUser> pageList=easyBuyUserDao.findByPage(pageBean.getPageNo(),pageBean.getPageSize());
		pageBean.setPageList(pageList);
		return pageBean;
	}
	public EasyBuyUser findByNickName(String nickName) {
		return easyBuyUserDao.findByNickName(nickName);
	}


	

}
