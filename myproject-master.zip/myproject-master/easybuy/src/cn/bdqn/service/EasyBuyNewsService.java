package cn.bdqn.service;

import java.sql.Timestamp;
import java.util.List;

import cn.bdqn.dao.EasyBuyNewsDao;
import cn.bdqn.entity.EasyBuyNews;
import cn.bdqn.util.PageBean;

public class EasyBuyNewsService {
	private EasyBuyNewsDao easyBuyNewsDao=new EasyBuyNewsDao();
	public List<EasyBuyNews> findTen() {
		return easyBuyNewsDao.findTen();
	}
	public EasyBuyNews findByTitle(int enId) {
		return easyBuyNewsDao.findByEnId(enId);
	}
	public PageBean<EasyBuyNews> findByPage(int pageNo, int pageSize) {
		PageBean<EasyBuyNews> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyNewsDao.getTotalCount();
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyNews> pageList=easyBuyNewsDao.findByPage(pageBean.getPageNo(),pageBean.getPageSize());
		pageBean.setPageList(pageList);
		return pageBean;
	}
	public int addNews(String title, String content, Timestamp createTime) {
		return easyBuyNewsDao.addNews(title,content,createTime);
	}
	public int updateNews(String title, String content, Timestamp createTime,int enId) {
		// TODO Auto-generated method stub
		return easyBuyNewsDao.updateNews(title,content,createTime,enId);
	}
	public EasyBuyNews findByEnId(int enId) {
		return easyBuyNewsDao.findByEnId(enId);
	}
	public int delNews(int enId) {
		// TODO Auto-generated method stub
		return easyBuyNewsDao.delNews(enId);
	}

}
