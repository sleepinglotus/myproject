package cn.bdqn.service;

import java.util.List;

import cn.bdqn.dao.EasyBuyCategoryDao;
import cn.bdqn.entity.EasyBuyCategory;
import cn.bdqn.util.PageBean;


public class EasyBuyCategoryService {
	private EasyBuyCategoryDao easyBuyCategoryDao=new EasyBuyCategoryDao();
	public List<EasyBuyCategory> findAll() {
		return easyBuyCategoryDao.findAll();
	}
	public EasyBuyCategory findByEpcId(int epcId) {
		return easyBuyCategoryDao.findByEpcId(epcId);
	}
	public PageBean<EasyBuyCategory> findByPage(int pageNo, int pageSize) {
		PageBean<EasyBuyCategory> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyCategoryDao.getTotalCount();
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyCategory> pageList=easyBuyCategoryDao.findByPage(pageBean.getPageNo(),pageBean.getPageSize());
		pageBean.setPageList(pageList);
		return pageBean;
	}
	public int updateCategory(String epcName, int parentId, int type, int epcId) {
		return easyBuyCategoryDao.updateCategory(epcName,parentId,type,epcId);
	}
	public int delCategory(int epcId) {
		return easyBuyCategoryDao.delCategory(epcId);
	}
	public int getCountByType(int type) {
		return easyBuyCategoryDao.getCountByType(type);
	}
	public int addCategory(String epcName, int parentId, int type) {
		return easyBuyCategoryDao.addCategory(epcName,parentId,type);
	}

}
