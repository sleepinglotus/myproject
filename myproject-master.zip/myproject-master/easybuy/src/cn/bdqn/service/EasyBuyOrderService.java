package cn.bdqn.service;

import java.sql.Timestamp;
import java.util.List;

import cn.bdqn.dao.EasyBuyOrderDao;
import cn.bdqn.entity.EasyBuyOrder;
import cn.bdqn.util.PageBean;

public class EasyBuyOrderService {
	EasyBuyOrderDao easyBuyOrderDao=new EasyBuyOrderDao();
	
	public PageBean<EasyBuyOrder> findAllByPage(int pageNo, int pageSize) {
		PageBean<EasyBuyOrder> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyOrderDao.getTotalCount();
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyOrder> pageList=easyBuyOrderDao.findByPage(pageBean.getPageNo(),pageBean.getPageSize());
		pageBean.setPageList(pageList);
		return pageBean;
	}

	public PageBean<EasyBuyOrder> findByEoId(int pageNo, int pageSize,int eoId) {
		PageBean<EasyBuyOrder> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyOrderDao.getCountByEoId(eoId);
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyOrder> pageList=easyBuyOrderDao.findByEoId(pageBean.getPageNo(),pageBean.getPageSize(),eoId);
		pageBean.setPageList(pageList);
		return pageBean;
	}

	public PageBean<EasyBuyOrder> findByNickName(int pageNo, int pageSize, String nickName) {
		PageBean<EasyBuyOrder> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyOrderDao.getCountByNickName(nickName);
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyOrder> pageList=easyBuyOrderDao.findByNickName(pageBean.getPageNo(),pageBean.getPageSize(),nickName);
		pageBean.setPageList(pageList);
		return pageBean;
	}

	public PageBean<EasyBuyOrder> findByEoIdAndNickName(int pageNo, int pageSize, int eoId, String nickName) {
		PageBean<EasyBuyOrder> pageBean=new PageBean<>();
		pageBean.setPageSize(pageSize);
		int totalCount=easyBuyOrderDao.getCountByEoIdAndNickName(eoId,nickName);
		pageBean.setTotalCount(totalCount);
		pageBean.setPageNo(pageNo);
		List<EasyBuyOrder> pageList=easyBuyOrderDao.findByEoIdAndNickName(pageBean.getPageNo(),pageBean.getPageSize(),eoId,nickName);
		pageBean.setPageList(pageList);
		return pageBean;
	}

	public int updateStatus(int status, int eoId) {
		return easyBuyOrderDao.updateStatus(status,eoId);
	}

	public int addOrderAndGetEoId(int userId, String address, Timestamp createTime, float cost, int status, int type) {
		int eoId=0;
		int ret=easyBuyOrderDao.addOrder(userId,address,createTime,cost,status,type);
		if(ret>0) {
			eoId=easyBuyOrderDao.getEpId();
		}
		return eoId;
	}

}
